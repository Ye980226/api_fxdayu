import logging
logging.getLogger(__name__).warning("大叔真帅")

