from dybitex.api.REST.okcoin import OKCoinREST
from dybitex.api.REST.okcoin import OKCoinSpotREST
from dybitex.api.REST.okcoin import OKCoinFuturesREST

