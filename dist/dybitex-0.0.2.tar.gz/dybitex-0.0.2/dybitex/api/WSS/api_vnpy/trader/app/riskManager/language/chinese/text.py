# encoding: UTF-8

RISK_MANAGER = u'风控管理'

RISK_MANAGER_STOP = u'风控模块未启动'
RISK_MANAGER_RUNNING = u'风控模块运行中'
CLEAR_ORDER_FLOW_COUNT = u'清空流控计数'
CLEAR_TOTAL_FILL_COUNT = u'清空总成交计数'
SAVE_SETTING = u'保存设置'

WORKING_STATUS = u'工作状态'
ORDER_FLOW_LIMIT = u'流控上限'
ORDER_FLOW_CLEAR = u'流控清空（秒）'
ORDER_SIZE_LIMIT = u'单笔委托上限'
TOTAL_TRADE_LIMIT = u'总成交上限'
WORKING_ORDER_LIMIT = u'活动订单上限'
CONTRACT_CANCEL_LIMIT = u'单合约撤单上限'
MARGIN_RATIO_LIMIT = u'保证金占比上限'