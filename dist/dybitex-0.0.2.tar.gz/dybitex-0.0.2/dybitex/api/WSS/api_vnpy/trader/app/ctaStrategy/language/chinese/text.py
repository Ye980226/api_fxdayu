# encoding: UTF-8

INIT = u'初始化'
START = u'启动'
STOP = u'停止'

CTA_ENGINE_STARTED = u'CTA引擎启动成功'

CTA_STRATEGY = u'CTA策略'
LOAD_STRATEGY = u'加载策略'
INIT_ALL = u'全部初始化'
START_ALL = u'全部启动'
STOP_ALL = u'全部停止'
SAVE_POSITION_DATA = u'保存持仓'

STRATEGY_LOADED = u'策略加载成功'

SAVE_POSITION_QUESTION = u'是否要保存策略持仓数据到数据库？'