# encoding: UTF-8

LOADING_ERROR = u'读取连接配置出错，请检查'
CONFIG_KEY_MISSING = u'连接配置缺少字段，请检查'
NONEED_TO_QRYACCOUNT = u'IB接口账户信息提供主推更新，无需查询'
NONEED_TO_QRYPOSITION = u'IB接口持仓信息提供主推更新，无需查询'

API_CONNECTED = u'IB接口连接成功，当前服务器时间{time}'
API_DISCONNECTED = u'IB接口连接断开'