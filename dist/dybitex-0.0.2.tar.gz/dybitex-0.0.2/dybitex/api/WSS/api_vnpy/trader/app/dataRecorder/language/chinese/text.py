# encoding: UTF-8

DATA_RECORDER = u'行情记录'

TICK_RECORD = u'Tick记录'
BAR_RECORD = u'Bar记录'
TICK_RECORD = u'Tick记录'

CONTRACT_SYMBOL = u'合约代码'
GATEWAY = u'接口'

DOMINANT_CONTRACT = u'主力合约'
DOMINANT_SYMBOL = u'主力代码'

TICK_LOGGING_MESSAGE = u'记录Tick数据{symbol}，时间:{time}, last:{last}, bid:{bid}, ask:{ask}'
BAR_LOGGING_MESSAGE = u'记录分钟线数据{symbol}，时间:{time}, O:{open}, H:{high}, L:{low}, C:{close}'