# encoding: UTF-8

RISK_MANAGER = u'Risk Manager'

RISK_MANAGER_STOP = u'RM Stop'
RISK_MANAGER_RUNNING = u'RM Running'
CLEAR_ORDER_FLOW_COUNT = u'Clear Flow Count'
CLEAR_TOTAL_FILL_COUNT = u'Clear Fill Count'
SAVE_SETTING = u'Save Setting'

WORKING_STATUS = u'Working Status'
ORDER_FLOW_LIMIT = u'Flow Limit'
ORDER_FLOW_CLEAR = u'Flow Clear(s)'
ORDER_SIZE_LIMIT = u'Order Size Limit'
TOTAL_TRADE_LIMIT = u'Total Fill Limit'
WORKING_ORDER_LIMIT = u'Working Order Limit'
CONTRACT_CANCEL_LIMIT = u'Contract Cancel Limit'
MARGIN_RATIO_LIMIT = u'Margin Ratio Limit'