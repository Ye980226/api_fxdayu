import logging
logging.getLogger(__name__).warning("The API clients available in this package are deprecated "
                                    "and will be no longer available in their current form "
                                    "starting with version 2.0!")
from dybitex.interfaces import OKCoin

