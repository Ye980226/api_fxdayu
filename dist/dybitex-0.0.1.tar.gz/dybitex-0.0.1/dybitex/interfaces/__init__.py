from dybitex.interfaces.okcoin import OKCoin

